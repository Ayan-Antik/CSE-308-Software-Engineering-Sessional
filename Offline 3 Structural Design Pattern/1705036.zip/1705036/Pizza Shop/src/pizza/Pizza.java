package pizza;

public interface Pizza {
    public String prepare();
    public double price();
}
