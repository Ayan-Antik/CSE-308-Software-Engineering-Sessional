package editor.parsers;

public class C implements Parser {
    @Override
    public void ParseFile() {
        System.out.println(".c Parser selected");
    }
}
