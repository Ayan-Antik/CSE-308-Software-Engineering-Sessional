package editor.parsers;

public interface Parser {
    public void ParseFile();
}
