package editor.parsers;

public class CPP implements Parser {
    @Override
    public void ParseFile() {
        System.out.println(".cpp Parser selected");
    }
}
