package editor.parsers;

public class Python implements Parser {
    @Override
    public void ParseFile() {
        System.out.println(".py Parser selected");
    }
}
