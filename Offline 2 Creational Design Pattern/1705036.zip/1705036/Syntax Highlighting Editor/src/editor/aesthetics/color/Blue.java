package editor.aesthetics.color;

public class Blue extends Color {

}
