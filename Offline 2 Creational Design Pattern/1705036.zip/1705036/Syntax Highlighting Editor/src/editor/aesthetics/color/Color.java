package editor.aesthetics.color;

import editor.aesthetics.Aesthetics;

public  abstract class Color{
}
