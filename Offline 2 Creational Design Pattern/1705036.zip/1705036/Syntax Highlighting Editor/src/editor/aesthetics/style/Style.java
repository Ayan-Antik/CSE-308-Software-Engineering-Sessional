package editor.aesthetics.style;

import editor.aesthetics.Aesthetics;

public abstract class Style{
}
