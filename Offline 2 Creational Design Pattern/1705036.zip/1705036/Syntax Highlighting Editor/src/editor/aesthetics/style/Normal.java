package editor.aesthetics.style;

public class Normal extends Style {
}
