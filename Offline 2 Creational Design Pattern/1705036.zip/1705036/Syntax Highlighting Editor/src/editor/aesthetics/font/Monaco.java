package editor.aesthetics.font;

public class Monaco extends Font {
}
