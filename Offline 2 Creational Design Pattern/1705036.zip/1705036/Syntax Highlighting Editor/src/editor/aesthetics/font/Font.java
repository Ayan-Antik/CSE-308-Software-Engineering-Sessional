package editor.aesthetics.font;


public abstract class Font{
}
