package editor.aesthetics.font;

public class Consolas extends Font {
}
