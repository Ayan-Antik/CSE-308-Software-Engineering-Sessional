package editor.aesthetics.font;

public class CourierNew extends  Font {
}
