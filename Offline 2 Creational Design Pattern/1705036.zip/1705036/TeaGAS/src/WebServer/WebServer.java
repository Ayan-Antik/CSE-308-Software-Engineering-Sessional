package WebServer;

public interface WebServer {
    String ServerType();
}
