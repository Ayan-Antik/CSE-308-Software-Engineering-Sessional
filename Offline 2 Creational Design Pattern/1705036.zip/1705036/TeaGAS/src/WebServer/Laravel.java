package WebServer;

public class Laravel implements WebServer{
    @Override
    public String ServerType() {
        return "Laravel";
    }
}
