package WebServer;

public class Spring implements WebServer {
    @Override
    public String ServerType() {
        return "Spring";
    }
}
