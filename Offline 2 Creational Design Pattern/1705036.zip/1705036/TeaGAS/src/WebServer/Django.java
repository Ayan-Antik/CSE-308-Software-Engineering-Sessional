package WebServer;

public class Django implements WebServer {

    @Override
    public String ServerType() {
        return "Django";
    }
}
