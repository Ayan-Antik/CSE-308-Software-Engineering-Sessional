package HardwareBuilder;

public interface SystemBuilder {
}
