package Hardware.WeightMeasurement;

public class LoadSensor extends WeightMeasurement{
    public String name(){
        return "Load Sensor";
    }
}
