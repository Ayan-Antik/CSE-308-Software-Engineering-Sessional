package Hardware.WeightMeasurement;

public class WeightModule extends WeightMeasurement{

    @Override
    public String name() {
        return "Weight Module";
    }
}
