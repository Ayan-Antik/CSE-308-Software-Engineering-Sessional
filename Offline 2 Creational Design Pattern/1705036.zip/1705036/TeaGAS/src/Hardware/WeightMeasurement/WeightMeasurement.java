package Hardware.WeightMeasurement;

import Hardware.Components;

public abstract class WeightMeasurement implements Components {
}
