package Hardware.InternetConnection;

import Hardware.Components;

public abstract class Internet implements Components {
}
