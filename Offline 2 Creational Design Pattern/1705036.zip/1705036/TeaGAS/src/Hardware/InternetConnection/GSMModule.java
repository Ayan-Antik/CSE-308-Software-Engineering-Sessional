package Hardware.InternetConnection;

public class GSMModule extends Internet{
    @Override
    public String name() {
        return "SIM Card";
    }
}
