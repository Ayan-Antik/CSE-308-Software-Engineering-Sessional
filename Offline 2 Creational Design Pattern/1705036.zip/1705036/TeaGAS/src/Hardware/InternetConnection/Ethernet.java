package Hardware.InternetConnection;

public class Ethernet extends Internet{
    @Override
    public String name() {
        return "Ethernet";
    }
}
