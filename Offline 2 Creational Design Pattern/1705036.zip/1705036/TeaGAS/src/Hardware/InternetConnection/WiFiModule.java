package Hardware.InternetConnection;

public class WiFiModule extends Internet{
    @Override
    public String name() {
        return "WiFi";
    }
}
