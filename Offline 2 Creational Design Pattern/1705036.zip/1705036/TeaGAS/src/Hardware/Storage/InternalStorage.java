package Hardware.Storage;

public class InternalStorage extends Storage {
    @Override
    public String name() {
        return "Internal Storage";
    }
}
