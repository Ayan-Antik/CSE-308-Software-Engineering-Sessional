package Hardware.Storage;

public class SDcard extends Storage{
    @Override
    public String name() {
        return "SD Card";
    }
}
