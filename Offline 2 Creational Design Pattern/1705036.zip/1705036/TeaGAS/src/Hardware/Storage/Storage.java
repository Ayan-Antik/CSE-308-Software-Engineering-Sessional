package Hardware.Storage;

import Hardware.Components;

public abstract class Storage implements Components {

}
