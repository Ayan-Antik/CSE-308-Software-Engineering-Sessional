package Hardware.Microcontroller;

import Hardware.Components;

public abstract class Microcontroller implements Components {
}
