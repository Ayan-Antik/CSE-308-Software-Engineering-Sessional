package Hardware.Microcontroller;

public class RaspberryPi extends Microcontroller{
    @Override
    public String name() {
        return "Raspberry Pi";
    }
}
