package Hardware.Microcontroller;

public class ArduinoMega extends Microcontroller {
    @Override
    public String name() {
        return "Arduino Mega";
    }
}
