package Hardware.Microcontroller;

public class ATMega32 extends Microcontroller{
    @Override
    public String name() {
        return "ATMega32";
    }
}
