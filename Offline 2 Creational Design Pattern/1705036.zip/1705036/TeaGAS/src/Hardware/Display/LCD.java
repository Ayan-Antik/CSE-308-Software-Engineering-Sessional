package Hardware.Display;

public class LCD extends Display{
    @Override
    public String name() {
        return "LCD";
    }
}
