package Hardware.Display;

public class LED extends Display {
    @Override
    public String name() {
        return "LED";
    }
}
