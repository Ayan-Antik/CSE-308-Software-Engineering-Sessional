package Hardware.Display;

import Hardware.Components;

public abstract class Display implements Components {
}
