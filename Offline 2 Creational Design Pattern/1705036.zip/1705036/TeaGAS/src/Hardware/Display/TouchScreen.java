package Hardware.Display;

public class TouchScreen extends Display{
    @Override
    public String name() {
        return "Touch Screen";
    }
}
