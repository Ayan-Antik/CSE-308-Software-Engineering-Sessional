package Hardware.Controller;

public class TouchScreenController extends Controller{
    @Override
    public String name() {
        return "Touch Screen Controller";
    }
}
