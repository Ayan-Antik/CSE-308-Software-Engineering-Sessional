package Hardware.Controller;

public class Button extends Controller{
    @Override
    public String name() {
        return "Button";
    }
}
