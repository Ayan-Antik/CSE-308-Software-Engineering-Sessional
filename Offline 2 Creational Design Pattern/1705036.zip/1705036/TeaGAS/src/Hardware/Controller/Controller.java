package Hardware.Controller;

import Hardware.Components;

public abstract class Controller implements Components {
}
