package Hardware;

public interface Components {

    public String name();
}
