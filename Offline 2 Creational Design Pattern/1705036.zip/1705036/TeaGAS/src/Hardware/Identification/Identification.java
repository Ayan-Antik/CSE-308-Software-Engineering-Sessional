package Hardware.Identification;

import Hardware.Components;

public abstract class Identification implements Components {
}
