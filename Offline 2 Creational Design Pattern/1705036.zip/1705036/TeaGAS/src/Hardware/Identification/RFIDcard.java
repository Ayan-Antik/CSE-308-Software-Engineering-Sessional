package Hardware.Identification;

public class RFIDcard extends Identification {
    @Override
    public String name() {
        return "RFID Card";
    }
}
