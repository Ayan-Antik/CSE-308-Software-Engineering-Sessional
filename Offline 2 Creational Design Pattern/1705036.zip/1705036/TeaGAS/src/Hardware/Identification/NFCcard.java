package Hardware.Identification;

public class NFCcard extends Identification{
    @Override
    public String name() {
        return "NFC Card";
    }
}
